 import('tailwindcss').Config

module.exports = {
  darkMode: 'class',
  theme: {
    darkMode: 'class',
    extend: {
      color: {
       
      },
    },
  },
  plugins: [],
}
